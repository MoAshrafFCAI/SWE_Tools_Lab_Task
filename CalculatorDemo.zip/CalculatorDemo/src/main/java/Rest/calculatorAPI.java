package Rest;

import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import Model.calculator;
import Service.calculatorService;

@Stateless
@Path("/API")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class calculatorAPI {

    @EJB
    calculatorService CalculatorService;

    @POST
    @Path("calculate")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response createCalculation(calculator Calculator) {
    	 try {
             double result = CalculatorService.calculation(Calculator);
             return Response.ok().entity("{\"Result\": " + result + "}").build();
         } catch (Exception ex) {
             return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("{\"error\": \"Internal Server Error\"}").build();
         }
    }
    
    
    @GET
    @Path("calculations")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getCalculations() {
        List<calculator> calcs = CalculatorService.getAllCalculations();
        return Response.ok().entity(calcs).build();
    }
}