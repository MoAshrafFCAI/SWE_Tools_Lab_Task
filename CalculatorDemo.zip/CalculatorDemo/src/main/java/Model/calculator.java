package Model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "calculator")
public class calculator {
	
	public calculator() {
		
	}
	
	 @Id //To use it in the database table 		
	 @GeneratedValue(strategy = GenerationType.IDENTITY)
	 int id;
	
	@Column(name="number1")
	 int number1;
	
	@Column(name = "number2")
	 int number2;
	
	@Column (name = "operation")
	 String operation;
    
    public void setNumber1(int num1) {
    	this.number1= num1;
    }
    
    public void setNumber2(int num2) {
    	this.number2= num2;
    }
    
    public void setOperation(String symbol) {
    	this.operation= symbol;
    }
   
    public int getNumber1() {
        return this.number1;
    }

    public int getNumber2() {
        return this.number2;
    }

    public String getOperation() {
        return this.operation;
    }

}