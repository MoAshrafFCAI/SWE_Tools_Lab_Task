package Service;

import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import Model.calculator;

@Stateless
public class calculatorService {
	@PersistenceContext(unitName= "calc")
	private EntityManager em;
	
	public double calculation (calculator Calculator) {
		int number1=Calculator.getNumber1();
		int number2=Calculator.getNumber2();
		String operation=Calculator.getOperation();
		double result;
        switch (operation) {
            case "+":
                result = number1 + number2;
                break;
            case "-":
                result = number1 - number2;
                break;
            case "*":
                result = number1 * number2;
                break;
            case "/":
            	if (number2 == 0) {
                    throw new IllegalArgumentException("Cannot divide by zero");
                }

                result = (double)number1 / number2;
                break;
                
            default:
                throw new IllegalArgumentException("Invalid operation, try another valid one");
    
	}
        em.persist(Calculator);
        return result;
        
   }
	
	public List<calculator> getAllCalculations() {
		TypedQuery<calculator> query = em.createQuery("SELECT e FROM  calculator e", calculator.class);
		return query.getResultList();
	}
}